Adds "carniculus", an alien race made of lumps of tumor. HAR & RJW required
 
contents⬇️
 
Carniculus (male and female)
- Easily goes raping & no emotional debuff when get raped
- gluttonous and eats fast
- Ugly and high filth rate
- Somewhat good at research and medicine
- Somewhat not good at socializing, building, or mining
 
"Mama", the subspecies
- Masochist
- Beautiful and vulnerable
 
- some apparels & weapons
- some body part textures for rimnude
 
Carnigigas (livestock)
- Made with human flesh.
- Other than that they are mostly the same as elephants.
 
"Metastasis and Proliferation" (scenario)
- Starts with 3 naked carniculus (or "mama") + one carnigigas
 
Carniculus’ trading ship (trader)
- Trader ships by carniculus who stayed on the spaceship.
- They are hoarding slaves and expensive goods.
